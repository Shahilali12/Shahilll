# coin

```js
// usage
chance.coin()
```

Flip a coin!

```js
chance.coin();
=> 'heads'

chance.coin();
=> 'tails'
```
