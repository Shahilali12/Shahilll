# Installation
> `npm install --save @types/validator`

# Summary
This package contains type definitions for validator.js (https://github.com/validatorjs/validator.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/validator.

### Additional Details
 * Last updated: Mon, 07 Aug 2023 20:32:47 GMT
 * Dependencies: none
 * Global values: `validator`

# Credits
These definitions were written by [tgfjt](https://github.com/tgfjt), [Ilya Mochalov](https://github.com/chrootsu), [Ayman Nedjmeddine](https://github.com/IOAyman), [Louay Alakkad](https://github.com/louy), [Bonggyun Lee](https://github.com/deptno), [Naoto Yokoyama](https://github.com/builtinnya), [Philipp Katz](https://github.com/qqilihq), [Jace Warren](https://github.com/keatz55), [Munif Tanjim](https://github.com/MunifTanjim), [Vlad Poluch](https://github.com/vlapo), [Piotr Błażejewicz](https://github.com/peterblazejewicz), [Matteo Nista](https://github.com/Mattewn99), [Roman Babiak](https://github.com/Almost-Infinity), and [Daniel Freire](https://github.com/dcfreire).
