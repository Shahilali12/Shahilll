import isISO6391 from '../../lib/isISO6391';
export default isISO6391;
