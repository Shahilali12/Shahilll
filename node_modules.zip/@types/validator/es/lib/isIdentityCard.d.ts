import validator from '../../';
export type IdentityCardLocale = validator.IdentityCardLocale;
export default validator.isIdentityCard;
