import validator from '../../';
export default validator.toBoolean;
