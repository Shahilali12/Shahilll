import { isISO6346, isFreightContainerID } from '../../lib/isISO6346';
export default isISO6346;
export { isFreightContainerID };
