import isFQDN, { IsFQDNOptions } from '../../lib/isFQDN';
export default isFQDN;
export { IsFQDNOptions };
