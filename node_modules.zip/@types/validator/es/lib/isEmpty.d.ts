import validator from '../../';
export type IsEmptyOptions = validator.IsEmptyOptions;
export default validator.isEmpty;
