import validator from '../../';
export default validator.isFullWidth;
