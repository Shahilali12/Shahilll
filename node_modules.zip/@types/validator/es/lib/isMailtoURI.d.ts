import isMailtoURI from '../../lib/isMailtoURI';
export default isMailtoURI;
