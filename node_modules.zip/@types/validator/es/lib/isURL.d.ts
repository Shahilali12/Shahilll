import isURL, { IsURLOptions } from '../../lib/isURL';
export default isURL;
export { IsURLOptions };
