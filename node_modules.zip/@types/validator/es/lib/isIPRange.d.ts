import validator from '../../';
export type IPVersion = validator.IPVersion;
export default validator.isIPRange;
