import isISO31661Alpha2, { CountryCodes } from '../../lib/isISO31661Alpha2';
export default isISO31661Alpha2;
export { CountryCodes };
