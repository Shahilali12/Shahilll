import validator from '../../';
export default validator.ltrim;
