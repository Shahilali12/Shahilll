import isBoolean, { Options } from '../../lib/isBoolean';
export default isBoolean;
export { Options };
