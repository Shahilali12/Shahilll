import validator from '../../';
export type IsByteLengthOptions = validator.IsByteLengthOptions;
export default validator.isByteLength;
