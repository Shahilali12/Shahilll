import validator from '../../';
export default validator.equals;
