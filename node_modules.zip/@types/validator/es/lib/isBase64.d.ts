import validator from '../../';
export default validator.isBase64;
