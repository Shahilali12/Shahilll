import validator from '../../';
export type NormalizeEmailOptions = validator.NormalizeEmailOptions;
export default validator.normalizeEmail;
