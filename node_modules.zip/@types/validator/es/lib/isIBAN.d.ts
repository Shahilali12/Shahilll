import isIBAN, { locales, IsIBANOptions as IsIBANValidationOptions } from '../../lib/isIBAN';
export default isIBAN;
export { locales };
export type IsIBANOptions = IsIBANValidationOptions;
