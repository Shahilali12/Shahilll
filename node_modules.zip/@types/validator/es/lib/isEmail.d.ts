import isEmail, { IsEmailOptions } from '../../lib/isEmail';
export default isEmail;
export { IsEmailOptions };
