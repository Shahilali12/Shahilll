import validator from '../';
export type MobilePhoneLocale = validator.MobilePhoneLocale;
export type IsMobilePhoneOptions = validator.IsMobilePhoneOptions;
export default validator.isMobilePhone;
