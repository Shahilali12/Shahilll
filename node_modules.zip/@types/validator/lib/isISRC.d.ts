import validator from '../';
export default validator.isISRC;
