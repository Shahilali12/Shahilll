import validator from '../';

export const isISO6346: typeof validator.isISO6346;
export const isFreightContainerID: typeof validator.isFreightContainerID;
