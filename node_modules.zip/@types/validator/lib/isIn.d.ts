import validator from '../';
export default validator.isIn;
