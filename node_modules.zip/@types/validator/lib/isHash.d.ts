import validator from '../';
export type HashAlgorithm = validator.HashAlgorithm;
export default validator.isHash;
