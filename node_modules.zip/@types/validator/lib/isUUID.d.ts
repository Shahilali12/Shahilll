import validator from '../';
export type UUIDVersion = validator.UUIDVersion;
export default validator.isUUID;
