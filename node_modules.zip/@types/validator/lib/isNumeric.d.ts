import validator from '../';
export type IsNumericOptions = validator.IsNumericOptions;
export default validator.isNumeric;
