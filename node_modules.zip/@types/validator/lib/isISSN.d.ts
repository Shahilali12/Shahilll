import validator from '../';
export type IsISSNOptions = validator.IsISSNOptions;
export default validator.isISSN;
