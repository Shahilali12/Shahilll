import validator from '../';
export type ISBNVersion = validator.ISBNVersion;
export default validator.isISBN;
