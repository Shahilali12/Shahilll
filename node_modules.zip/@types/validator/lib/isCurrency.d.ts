import validator from '../';
export type IsCurrencyOptions = validator.IsCurrencyOptions;
export default validator.isCurrency;
