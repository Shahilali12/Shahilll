import validator from '../';
export type FloatLocale = validator.FloatLocale;
export type IsFloatOptions = validator.IsFloatOptions;
export default validator.isFloat;
