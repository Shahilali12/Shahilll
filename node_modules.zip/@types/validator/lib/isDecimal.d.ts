import validator from '../';
export type IsDecimalOptions = validator.IsDecimalOptions;
export type DecimalLocale = validator.DecimalLocale;
export default validator.isDecimal;
