import validator from '../';
export default validator.isBtcAddress;
