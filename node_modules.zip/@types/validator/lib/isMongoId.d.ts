import validator from '../';
export default validator.isMongoId;
