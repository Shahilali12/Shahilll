import validator from '../';
export default validator.isISO31661Alpha3;
